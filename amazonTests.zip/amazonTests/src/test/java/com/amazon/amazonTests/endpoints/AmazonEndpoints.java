package com.amazon.amazonTests.endpoints;

public class AmazonEndpoints {
    public static String getAmazonURL(String url) {
        url = "https://www.amazon.in/";
        return (url);
    }
}
