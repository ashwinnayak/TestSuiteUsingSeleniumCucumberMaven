package com.amazon.amazonTests.Utils;

import cucumber.api.java.en.And;
import junit.framework.Assert;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;


import cucumber.api.CucumberOptions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

public class ReusableSteps {
    public String methodReturnResult = null;
    public static String screenshotPath = System.getProperty("user.dir") + "\\Reports\\";
    public static long unixTime = System.currentTimeMillis();
    public static String path = System.getProperty("user.dir");

    public static void assertTitle(WebDriver driver, String expectedTitle) {

        String actualTitle = null;

        System.out.println("Asserting  title  where : Expected title = " + expectedTitle);

        try {

            // Fetch actual title of the webpage
            actualTitle = driver.getTitle();

            // Asserts whether actual title matches with expected one
            Assert.assertEquals(expectedTitle.trim(), actualTitle.trim());

            // Log result
            System.out.println("Actual title = " + actualTitle + " and matches with Expected title = " + expectedTitle);


        } catch (Throwable assertTitleException) {

            // Log error
            takeScreenShot(driver, screenshotPath, "title_" + unixTime + ".jpg");
            System.err.println("Error while asserting title : " + assertTitleException.getMessage());

        }

    }

    public static void takeScreenShot(WebDriver driver, String filePath, String filename) {

        // Take screenshot and store as a file format
        String screenShotPath = filePath + filename;
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File(screenShotPath));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void clickLink(WebDriver driver, By locator, String elemName) throws IOException {

        System.out.println("Clicking on : " + elemName);

        try {
            // Click on the link
            driver.findElement(locator).click();

            //Implicitly wait for 10 seconds for the page to load
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            // Log result
            System.out.println("Clicked on : " + elemName);

            Thread.sleep(2000);

        } catch (Throwable clickLinkException) {

            takeScreenShot(driver, screenshotPath, elemName + unixTime + ".jpg");
            // Log error
            System.err.println("Error while clicking on - '" + elemName + "' : " + clickLinkException.getMessage());

        }

    }

    //Input value to fields
    public static void input(WebDriver driver, By locator, String elemName, String value) {

        System.out.println("Sending Values in : " + elemName);

        try {

            // Send values to the input box
            driver.findElement(locator).sendKeys(value);
            Thread.sleep(3000);
            //Implicitly wait for 5 seconds for the page to load
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            // Log result
            System.out.println("Input '" + value + "' text into : " + elemName);
        } catch (Throwable inputException) {

            takeScreenShot(driver, screenshotPath, elemName + unixTime + ".jpg");
            // Log error
            System.err.println("Error while inputting into - " + elemName + " : " + inputException.getMessage());

        }

    }

    public static void isElementPresent(By Locator, String elemName, WebDriver driver) {

        System.out.println("Verifying whether Element : " + elemName + " is present");

        Boolean present = null;

        try {

            // Wait for web element to load
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


            // Verify whether element is displayed on the page or not
            present = driver.findElement(Locator).isDisplayed();

            // Log result
            if (present) {

                System.out.println("Element : " + elemName + " is present");

            } else {

                System.out.println("Element : " + elemName + " is not present");

            }

        } catch (Throwable isElementPresentException) {

            takeScreenShot(driver, screenshotPath, "elemName" + unixTime + ".jpg");

            // Log error
            System.err.println("Error while verifying - " + elemName + " element Present : " + isElementPresentException.getMessage());

        }

    }

    public static void waitForElementToAppear(WebDriver driver, By locator, String elemName) {

        System.out.println("Waiting for web element to load on the page");

        try {

            // Waits for 60 seconds
            Wait<WebDriver> wait = new WebDriverWait(driver, 60);

            // Wait until the element is located on the page
            WebElement element = wait.until(visibilityOfElementLocated(locator));

            // Log result
            System.out.println("Waiting ends ... Web element loaded on the page");

        } catch (Throwable waitForElementException) {
            takeScreenShot(driver, screenshotPath, elemName + unixTime + ".jpg");
            // Log error
            System.err.println("Error came while waiting for element to appear : " + waitForElementException.getMessage());

        }

    }

    public static void closeDriver(WebDriver driver) {

        System.out.println("Closing the driver ...");

        try {

            // Close the driver
            driver.quit();

            // Log result
            System.out.println("Closed the driver");

        } catch (Throwable closeDriverException) {

            takeScreenShot(driver, screenshotPath, "Cannot close driver" + unixTime + ".jpg");
            // Log error
            System.err.println("Error came while closing driver : " + closeDriverException.getMessage());

        }

    }


}
