package com.amazon.amazonTests.steps;

import com.amazon.amazonTests.Utils.ReusableSteps;
import com.amazon.amazonTests.endpoints.AmazonEndpoints;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class AmazonStepDefinition extends ReusableSteps {
    public String amazonURL = null;
    public static String pageTitle_amazon = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";

    DesiredCapabilities capability = DesiredCapabilities.chrome();
    WebDriver driver = new ChromeDriver();
    Actions actions = new Actions(driver);

    @Given("^I open a browser and navigate to amazon via \"([^\"]*)\"$")
    public void iOpenABrowserAndNavigateToAmazonVia(String url) {

        amazonURL = AmazonEndpoints.getAmazonURL(url);
        System.setProperty("webdriver.chrome.driver", path + "\\chromedriver.exe");

        //Navigate to makemytrip website
        driver.manage().window().maximize();
        driver.get(amazonURL);

        //Implicitly wait for 10 seconds for the page to load
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


        //Assert whether or not it was navigated to amazon's homepage
        ReusableSteps.assertTitle(driver, pageTitle_amazon);
    }

    @Then("^I sign in to amazon$")
    public void iSignInToAmazon() throws IOException {

        ReusableSteps.clickLink(driver, By.xpath("//span[normalize-space(text()) = 'Hello. Sign in']/following-sibling::span[1]/span"), "Sign In button");

        ReusableSteps.isElementPresent(By.xpath("//input[@type='email']"), "Email or phone number textbox", driver);

        //Enter login details
        ReusableSteps.input(driver, By.xpath("//input[@type='email']"), "Email or phone number textbox", "");

        //Click on continue
        ReusableSteps.clickLink(driver, By.id("continue"), "Continue button");

        //Wait for
        ReusableSteps.waitForElementToAppear(driver, By.xpath("//input[@type='password']"), "Password field");

        //Enter password
        ReusableSteps.input(driver, By.xpath("//input[@type='password']"), "Password field", "");

        //Click on Login button
        ReusableSteps.clickLink(driver, By.id("signInSubmit"), "Continue button");

        //Verify that home page is reached


    }

    @Then("^I sign out of amazon$")
    public void iSignOutOfAmazon() throws IOException {

        WebElement dropdown = driver.findElement(By.xpath("//span[normalize-space(text()) = 'Account & Lists'][1]/span"));
        actions.moveToElement(dropdown).perform();

        //Click on Sign out from the dropdown
        ReusableSteps.clickLink(driver, By.id("nav-item-signout"), "Sign out button");
    }

    @And("^I close the browser$")
    public void iCloseTheBrowser() {

        //Close the driver
        ReusableSteps.closeDriver(driver);

    }
}

